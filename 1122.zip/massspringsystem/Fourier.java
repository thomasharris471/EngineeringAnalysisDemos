import java.util.ArrayList;

public class Fourier {
  
  ArrayList<Double> frequencyAmounts;
  ArrayList<Double> data;
  double lowerFrequency;
  double upperFrequency;
  double dw;
  double dt;
  
  public Fourier() {
    frequencyAmounts = new ArrayList<Double>(); 
    lowerFrequency = 1;
    upperFrequency = 20;
    dw = 0.1;
     data = new ArrayList<Double>();
  }
  
  public void updateFreqs() {
    frequencyAmounts.clear();
    for (double w = lowerFrequency; w < upperFrequency; w = w + dw) {
      frequencyAmounts.add(convolve(w)); 
    }
    /*
    double norm= 0;
    for (Double d: frequencyAmounts) {
      norm = norm + d*d*dw;
    }
    if (norm <=0) {
        norm = 1;
    }
    double holder = 0;
    for (int i = 0; i <  frequencyAmounts.size(); i++) {
       holder = frequencyAmounts.get(i);
       frequencyAmounts.set(i, 100000*holder/norm);
    }
    */
  }
  
  public double convolve(double frequency) {
    double cosTerm = 0;
    double sinTerm = 0;
    
    for (int i = 0; i < data.size(); i++) {
      cosTerm = cosTerm + Math.cos(frequency*dt*i)*data.get(i); 
      sinTerm = sinTerm + Math.sin(frequency*dt*i)*data.get(i); 
    }
    return Math.sqrt(cosTerm*cosTerm + sinTerm*sinTerm);
  }
  
  
 
  
  
}
