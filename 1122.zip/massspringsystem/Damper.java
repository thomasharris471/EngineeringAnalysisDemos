public class Damper {
  
  public Mass leftMass;
  public Mass rightMass;
  public double damperConstant;
  
  public Damper() {
    damperConstant = 2; 
  }
  
  
    public double[] computeForce(Mass whichMass) {

     
     double vx0 = leftMass.vx;
     double vx1 = rightMass.vx;
     double vy0 = leftMass.vy;
     double vy1 = rightMass.vy;
     
     double effectiveXVelocity = (vx0+vx1)/2.0;
     double effectiveYVelocity = (vy0+vy1)/2.0;
     
     double relativeX = 0;
     double relativeY = 0;
     

     double[] direction = {0,0};

     if (whichMass == leftMass) {
       relativeX = (vx0 - effectiveXVelocity);
       relativeY = (vy0 - effectiveYVelocity);
       
       direction[0] = -(damperConstant*relativeX);
       direction[1] = -(damperConstant*relativeY);
     } else if(whichMass == rightMass) {
       relativeX = (vx1 - effectiveXVelocity);
       relativeY = (vy1 - effectiveYVelocity);
       
       direction[0] = -(damperConstant*relativeX);
       direction[1] = -(damperConstant*relativeY);
     } else {
        
     }
     return direction;
  }
  
  
}
